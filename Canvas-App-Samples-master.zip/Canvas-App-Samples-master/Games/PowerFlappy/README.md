# Power Flappy
Side scroller Canvas App

Demonstrates:
-Sprite Manipulation
-Collision Detection

See
